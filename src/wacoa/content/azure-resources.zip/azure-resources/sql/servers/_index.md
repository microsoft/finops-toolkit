---
title: sqlServer
geekdocCollapseSection: true
geekdocHidden: false
---

{{< yamltotable2 resourceType="sql" resource="servers" >}}


##  Check for Idle SQL elastic pool
{{< kqltomd file="50987aae-a46d-49ae-bd41-a670a4dd18bd" >}}

