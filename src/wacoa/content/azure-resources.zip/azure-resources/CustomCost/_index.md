## Table of Contents

{{< toc dir="azure-resources/customcost" >}}
