---
title: Advisor
geekdocCollapseSection: true
geekdocHidden: false
---


# Advisor recommendations

This query will show all the Advisor recommendations related to cost optimization.


## Review all cost related Advisor recommendations
{{< kqltomd file="84a8b25f-0088-44ce-ac35-19e846b055dd" >}}

<!-- TO DO

Work on the tables.html shortcut to make it dinamic. 

{{< table file="recommendations\azure-resources\compute\disks\recommendations" >}}
 -->

