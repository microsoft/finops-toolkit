---
title: publicIPAddresses
geekdocCollapseSection: true
geekdocHidden: false
---


{{< yamltotable2 resourceType="network" resource="publicIPAddresses" >}}


##  Check for idle LB
{{< kqltomd file="3ecbf770-9404-4504-a450-cc198e8b2a7d" >}}

