---
title: loadBalancer
geekdocCollapseSection: true
geekdocHidden: false
---


{{< yamltotable2 resourceType="network" resource="loadBalancer" >}}


##  Check for idle LB
{{< kqltomd file="ab703887-fa23-4915-abdc-3defbea89f7a" >}}

