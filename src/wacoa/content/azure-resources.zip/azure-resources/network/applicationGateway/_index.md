---
title: applicationGateway
geekdocCollapseSection: true
geekdocHidden: false
---



{{< yamltotable2 resourceType="network" resource="applicationGateway" >}}


##  Check for idle AppGW
{{< kqltomd file="4f69df93-5972-44e0-97cf-4343c2bcf4b8" >}}

