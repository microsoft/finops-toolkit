---
title: virtualMachines
geekdocCollapseSection: true
geekdocHidden: false
---


{{< yamltotable2 resourceType="compute" resource="virtualMachines" >}}


##  Check OS power status
{{< kqltomd file="ab2ff882-e927-4093-9d11-631be0219975" >}}


##  Show Windows VM without AHB
{{< kqltomd file="f326c065-b9f7-4a0e-a0f1-5a1c060bc25d" >}}