---
title: Disks
geekdocCollapseSection: true
geekdocHidden: false
---


# Disk Recommendations

{{< yamltotable2 resourceType="compute" resource="disks" >}}


## Check idle managed disk{#idle-managed-disk}
{{< kqltomd file="e0c02939-ce02-4f9d-881f-8067ae7ec90f" >}}

<!-- TO DO

Work on the tables.html shortcut to make it dinamic. 

{{< table file="recommendations\azure-resources\compute\disks\recommendations" >}}
 -->

